from pathlib import Path
import json, re
DANGEROUS = [r"import\s+requests", r"urllib", r"socket", r"subprocess", r"os\.system", r"eval\(", r"exec\(", r"selenium", r"playwright", r"keylogger", r"pynput"]

def audit_tree(root: str):
    findings=[]
    for p in Path(root).rglob("*.py"):
        if p.name == "static_audit.py":
            continue
        txt=p.read_text(encoding="utf-8", errors="ignore")
        for pat in DANGEROUS:
            if re.search(pat, txt):
                findings.append({"file":str(p),"pattern":pat})
    return {"pass": not findings, "finding_count": len(findings), "findings": findings, "policy":"No network imports, subprocess, dynamic execution, credential capture, hidden telemetry, stalking, or manipulation helpers in offline core."}

def write_audit(root: str, out: str):
    res=audit_tree(root)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    return res
