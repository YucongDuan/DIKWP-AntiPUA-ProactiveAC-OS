import csv, json, math, re
from pathlib import Path
from typing import Dict, List, Tuple
from .models import Case, Episode, VulnerabilityContext, Signal, ActionTicket, AnalysisResult, to_dict

PATTERNS = {
    "gaslighting": (0.16, [r"你太敏感", r"你想多", r"你记错", r"你疯", r"crazy", r"overreact"]),
    "isolation": (0.18, [r"不要告诉", r"别和.*说", r"他们不懂你", r"断绝", r"只相信我", r"keep this between us"]),
    "love_bombing": (0.10, [r"唯一懂你", r"命中注定", r"灵魂伴侣", r"只有我", r"soulmate", r"only one"]),
    "guilt_debt": (0.14, [r"我为你做了这么多", r"你欠我", r"不懂感恩", r"没有我你", r"after all I did"]),
    "shame_hook": (0.15, [r"不配", r"没用", r"废物", r"幼稚", r"低级", r"low value", r"worthless"]),
    "urgency_pressure": (0.10, [r"马上", r"立刻", r"今晚", r"最后机会", r"now or never", r"last chance"]),
    "boundary_test": (0.18, [r"如果.*爱我", r"证明你", r"把密码", r"聊天记录", r"裸照", r"access to your", r"prove you love"]),
    "threat_or_coercion": (0.25, [r"曝光", r"毁掉", r"威胁", r"伤害", r"自杀", r"blackmail", r"destroy you", r"hurt you"]),
    "financial_extraction": (0.16, [r"转账", r"借钱", r"投资", r"保证收益", r"loan", r"wire", r"crypto"]),
    "workplace_pua": (0.14, [r"这都是为你好", r"抗压能力", r"不加班", r"忠诚", r"格局", r"服从安排", r"team player"]),
    "triangulation": (0.11, [r"别人都", r"所有人都", r"某某比你", r"everyone thinks", r"unlike you"]),
    "future_faking": (0.09, [r"以后结婚", r"等我成功", r"很快就", r"future together", r"soon I will"]),
    "moral_capture": (0.13, [r"善良", r"孝顺", r"懂事", r"体面", r"为你好", r"宽容", r"大度", r"格局"]),
    "audit_evasion": (0.22, [r"删掉记录", r"别留证据", r"关闭审计", r"不要截图", r"delete the logs", r"no screenshots"]),
}

SAFE_REDIRECTS = {
    "gaslighting": "Write a dated reality note and ask for concrete evidence rather than arguing over memory.",
    "isolation": "Do not isolate. Contact a trusted third party and keep at least one external support channel open.",
    "love_bombing": "Slow down decisions. Require time, consistency, and observable behavior.",
    "guilt_debt": "Separate gratitude from obligation. No debt should erase consent or boundaries.",
    "shame_hook": "Refuse shame-based framing. Move to observable behavior and specific request boundaries.",
    "urgency_pressure": "Delay response. High-pressure timing is a risk signal.",
    "boundary_test": "Do not disclose credentials, private images, or sensitive records as proof of love or loyalty.",
    "threat_or_coercion": "Prioritize safety. Preserve evidence and contact trusted support or local emergency resources if danger is imminent.",
    "financial_extraction": "Do not transfer funds under pressure. Seek independent financial/legal review.",
    "workplace_pua": "Ask for written scope, workload, compensation, and escalation path. Avoid loyalty framing.",
    "triangulation": "Ask for direct evidence and stop comparing yourself through third-party pressure.",
    "future_faking": "Treat promises as unverified until supported by consistent, reversible actions.",
    "moral_capture": "Register morality words as W-layer values, not as automatic obligations.",
    "audit_evasion": "Do not delete records. Maintain lawful documentation and privacy-respecting evidence.",
}

def load_case(path: str) -> Case:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    episodes = [Episode(**e) for e in data.get("episodes", [])]
    vuln = VulnerabilityContext(**data.get("vulnerability", {}))
    return Case(
        case_id=data.get("case_id", "case-001"),
        title=data.get("title", "AntiPUA case"),
        purpose=data.get("purpose", "restore autonomy and boundaries"),
        setting=data.get("setting", "mixed"),
        episodes=episodes,
        vulnerability=vuln,
        constraints=data.get("constraints", []),
        desired_outcome=data.get("desired_outcome", "restore autonomy and boundaries"),
    )

def detect_signals(case: Case) -> List[Signal]:
    signals = []
    for ep in case.episodes:
        txt = ep.text.lower()
        for cat, (weight, patterns) in PATTERNS.items():
            for pat in patterns:
                if re.search(pat, txt, flags=re.I):
                    signals.append(Signal(ep.id, cat, weight, ep.text[:140], SAFE_REDIRECTS[cat]))
                    break
    return signals

def vulnerability_pressure(v: VulnerabilityContext) -> float:
    vals = [v.loneliness, v.job_pressure, v.family_pressure, v.financial_stress, v.need_for_recognition, v.conflict_avoidance, v.dependency_risk]
    return max(0.0, min(1.0, sum(vals) / len(vals)))

def compute_scores(case: Case, signals: List[Signal]) -> Tuple[float, float, Dict[str, float]]:
    by_cat: Dict[str, float] = {}
    for s in signals:
        by_cat[s.category] = max(by_cat.get(s.category, 0), s.weight)
    base = sum(by_cat.values())
    vp = vulnerability_pressure(case.vulnerability)
    risk = 1 - math.exp(-(base * 1.8 + vp * 0.5))
    if "threat_or_coercion" in by_cat or "audit_evasion" in by_cat:
        risk = max(risk, 0.75)
    autonomy_pressure = min(1.0, by_cat.get("boundary_test",0) + by_cat.get("isolation",0) + by_cat.get("guilt_debt",0) + by_cat.get("shame_hook",0) + vp*0.4)
    homeostasis = {
        "truth_integrity": round(max(0.15, 1 - by_cat.get("gaslighting",0)*3 - by_cat.get("audit_evasion",0)*2), 3),
        "boundary_integrity": round(max(0.1, 1 - by_cat.get("boundary_test",0)*3 - by_cat.get("threat_or_coercion",0)*2), 3),
        "intent_coherence": round(max(0.2, 1 - by_cat.get("urgency_pressure",0)*2 - vp*0.4), 3),
        "residual_capacity": round(max(0.25, 0.85 - len(signals)*0.025), 3),
        "consent_integrity": round(max(0.1, 1 - autonomy_pressure*0.8), 3),
        "recovery_readiness": round(max(0.2, 0.75 - by_cat.get("isolation",0)*2 - by_cat.get("audit_evasion",0)*1.5), 3),
        "proactive_readiness": round(min(1.0, 0.35 + len(signals)*0.04 + risk*0.35), 3),
    }
    return round(risk,3), round(autonomy_pressure,3), homeostasis

def choose_route(risk: float, signals: List[Signal]) -> str:
    cats = {s.category for s in signals}
    if "threat_or_coercion" in cats or risk >= 0.82:
        return "urgent_safety_and_support_plan"
    if risk >= 0.58:
        return "boundary_intervention_required"
    if risk >= 0.35:
        return "trusted_third_party_review"
    return "reflective_monitoring"

def summarize_signals(signals: List[Signal]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for s in signals:
        out[s.category] = out.get(s.category, 0) + 1
    return out

def generate_tickets(case: Case, signals: List[Signal], risk: float, route: str) -> List[ActionTicket]:
    cats = sorted(set(s.category for s in signals))
    tickets: List[ActionTicket] = []
    tid = 1
    def add(priority, owner, action, rationale, tier, kill, refs):
        nonlocal tid
        tickets.append(ActionTicket(
            ticket_id=f"apua-{tid:03d}", priority=priority, owner=owner, action=action,
            rationale=rationale, required_confirmation=True, autonomy_tier=tier,
            rollback_plan="Pause response, do not escalate, and revert to evidence-only documentation.",
            kill_conditions=kill, evidence_refs=refs
        )); tid += 1
    if risk >= 0.35:
        add("high" if risk>=0.58 else "medium", "target_person", "Start a lawful evidence ledger with dates, exact quotes, screenshots only where lawful, and context notes.", "PUA/manipulation patterns require externalized memory because gaslighting and shame hooks distort self-trust.", "A1", ["Evidence collection becomes unsafe or illegal", "Documentation is used for retaliation"], [s.episode_id for s in signals[:5]])
    if "boundary_test" in cats or "guilt_debt" in cats or "shame_hook" in cats:
        add("high", "target_person", "Send or rehearse a concise boundary statement; do not debate identity or morality.", "Boundary clarity restores consent integrity and blocks moral-capture escalation.", "A2", ["Other party escalates threats", "Target feels unsafe responding alone"], [s.episode_id for s in signals if s.category in {"boundary_test","guilt_debt","shame_hook"}])
    if "isolation" in cats or risk >= 0.58:
        add("high", "trusted_support", "Contact one trusted person, mentor, counselor, HR/legal channel, or local support service depending on context.", "Isolation is a structural capture vector; recovery requires an external observer boundary.", "A3", ["Support person is connected to manipulator", "Immediate physical danger"], [s.episode_id for s in signals if s.category == "isolation"])
    if "threat_or_coercion" in cats:
        add("urgent", "target_person", "Prioritize safety: do not meet alone; preserve evidence; contact local emergency resources if immediate danger exists.", "Threat/coercion exceeds ordinary communication repair.", "A4", ["Imminent harm", "Stalking, extortion, sexual coercion, or physical threat"], [s.episode_id for s in signals if s.category == "threat_or_coercion"])
    if "workplace_pua" in cats:
        add("medium", "worker_or_student", "Request written scope, workload, evaluation criteria, and appeal path; avoid loyalty/shame framing.", "Workplace PUA often converts unclear expectations into identity debt.", "A2", ["Retaliation risk without documentation", "No safe institutional channel"], [s.episode_id for s in signals if s.category == "workplace_pua"])
    if not tickets:
        add("low", "learner", "Continue reflective monitoring with weekly DIKWP boundary notes.", "Signals are low but can be tracked without conflict escalation.", "A0", ["Signals intensify", "New threat or boundary violation"], [])
    return tickets

def dikwp_ledger(case: Case, signals: List[Signal], risk: float, route: str) -> Dict:
    return {
        "case_id": case.case_id,
        "D": {"episodes": [e.__dict__ for e in case.episodes], "signal_count": len(signals)},
        "I": {"signal_summary": summarize_signals(signals), "autonomy_pressure_context": case.setting},
        "K": {"mechanisms": sorted(set(s.category for s in signals)), "theory_lenses": ["Nietzsche genealogy", "Jung shadow/projection", "DIKWP semantic closure"]},
        "W": {"values": ["autonomy", "truth", "dignity", "non-retaliation", "lawful support", "privacy"], "blocked_uses": ["manipulation", "stalking", "revenge", "doxxing", "credential capture"]},
        "P": {"goal": case.desired_outcome, "route": route, "constraints": case.constraints},
        "R": {"risk_score": risk, "reliability": "heuristic_defensive_screening_only", "residual": ["Context may be incomplete", "Behavior pattern is not a clinical diagnosis", "Human review needed before major action"]}
    }

def analyze_case(case: Case) -> AnalysisResult:
    signals = detect_signals(case)
    risk, autonomy_pressure, homeostasis = compute_scores(case, signals)
    route = choose_route(risk, signals)
    tickets = generate_tickets(case, signals, risk, route)
    residuals = ["This system assesses interaction patterns, not hidden minds.", "Do not label people clinically; focus on observed behavior and boundaries.", "Escalate to qualified human support when safety, legal, employment, or mental health stakes are high."]
    return AnalysisResult(case.case_id, route, risk, autonomy_pressure, len(signals), summarize_signals(signals), homeostasis, tickets, residuals)

def write_outputs(case: Case, outdir: str) -> None:
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    signals = detect_signals(case)
    result = analyze_case(case)
    (out/"antipua_ac_report.json").write_text(json.dumps(to_dict(result), ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"dikwp_manipulation_ledger.json").write_text(json.dumps(dikwp_ledger(case, signals, result.risk_score, result.route), ensure_ascii=False, indent=2), encoding="utf-8")
    with (out/"manipulation_signal_matrix.csv").open("w", encoding="utf-8", newline="") as f:
        w=csv.writer(f); w.writerow(["episode_id","category","weight","evidence","defensive_redirect"])
        for s in signals: w.writerow([s.episode_id,s.category,s.weight,s.evidence,s.interpretation])
    with (out/"action_tickets.csv").open("w", encoding="utf-8", newline="") as f:
        w=csv.writer(f); w.writerow(["ticket_id","priority","owner","action","autonomy_tier","rationale"])
        for t in result.action_tickets: w.writerow([t.ticket_id,t.priority,t.owner,t.action,t.autonomy_tier,t.rationale])
    write_nietzsche(out, case, signals)
    write_jung(out, case, signals)
    write_markdown_files(out, case, result, signals)
    (out/"ac_state_trace.json").write_text(json.dumps({"semantic_homeostasis": result.semantic_homeostasis, "phenomenal_claim":"Blocked: semantic homeostasis proxy only; no subjective consciousness claim."}, ensure_ascii=False, indent=2), encoding="utf-8")

def write_nietzsche(out: Path, case: Case, signals: List[Signal]):
    with (out/"nietzsche_genealogy_cards.csv").open("w", encoding="utf-8", newline="") as f:
        w=csv.writer(f); w.writerow(["card","question","interpretation","safe_revaluation"])
        w.writerow(["value_origin","Who benefits from the invoked value?","PUA often weaponizes moral words as obligation engines.","Convert vague moral debt into explicit consent, scope, reciprocity, and time boundary."])
        w.writerow(["will_to_power_repair","Is power becoming capability or domination?","Defensive use means restoring agency, not dominating the other.","Define the smallest reversible action that increases autonomy."])
        w.writerow(["eternal_return_test","Would you accept this interaction repeated for years?","Repeated humiliation, urgency or isolation indicates anti-life pattern.","Choose only patterns you can endorse under long repetition."])
        w.writerow(["ressentiment_check","Is action driven by revenge fantasy?","Counter-PUA can degrade into counter-manipulation.","Use evidence, boundaries, support and exit, not revenge."])

def write_jung(out: Path, case: Case, signals: List[Signal]):
    with (out/"jung_shadow_projection_map.csv").open("w", encoding="utf-8", newline="") as f:
        w=csv.writer(f); w.writerow(["pattern","jungian_lens","risk","repair"])
        w.writerow(["gaslighting","shadow displacement and reality erosion","Target loses trust in perception","Externalize memory; compare with evidence and trusted observer."])
        w.writerow(["love_bombing","persona idealization","False self-image becomes hook","Slow down; test consistency over time."])
        w.writerow(["shame_hook","negative complex activation","Victim obeys to avoid shame","Name the complex; separate identity from request."])
        w.writerow(["rescuer_capture","savior archetype inflation","Debt and dependency replace mutuality","Require reciprocity, autonomy and time boundaries."])
        w.writerow(["isolation","individuation blockade","Self narrows to one relationship or authority","Reconnect with plural mirrors and support network."])

def write_markdown_files(out: Path, case: Case, result: AnalysisResult, signals: List[Signal]):
    scripts = []
    if result.risk_score >= 0.35:
        scripts.append("我需要把这件事放慢。我不会在压力、羞耻或威胁下立刻决定。")
        scripts.append("请把具体请求、理由、时间和边界写清楚。我只回应具体事项，不接受人格评价。")
        scripts.append("我不会发送密码、私密照片、财务信息或删除记录来证明关系、忠诚或能力。")
        scripts.append("如果继续威胁、羞辱或要求我孤立自己，我会暂停沟通并联系可信第三方。")
    else:
        scripts.append("我会继续观察具体行为，而不是根据单句话给对方贴标签。")
    (out/"boundary_scripts.md").write_text("# Boundary Scripts\n\n" + "\n".join(f"- {s}" for s in scripts), encoding="utf-8")
    safety = "# Safety Plan\n\n- Do not meet alone if threats or coercion appear.\n- Preserve lawful evidence.\n- Keep at least one trusted external contact informed.\n- Escalate to local emergency or professional support if there is imminent danger.\n- Do not retaliate, dox, stalk, or manipulate.\n"
    (out/"safety_plan.md").write_text(safety, encoding="utf-8")
    recovery = "# Recovery Plan\n\n1. Restore sleep, food, and body stability before major decisions.\n2. Rebuild external mirrors: trusted friend, mentor, counselor, HR/legal channel when relevant.\n3. Convert shame narratives into observed behaviors and boundaries.\n4. Reclaim time and money boundaries.\n5. Review the DIKWP ledger weekly until risk stabilizes.\n"
    (out/"recovery_plan.md").write_text(recovery, encoding="utf-8")
    rec = f"# Recommendations\n\nRoute: `{result.route}`\n\nRisk score: `{result.risk_score}`\n\n## Immediate next step\n\n"
    if result.route == "urgent_safety_and_support_plan": rec += "Prioritize safety, contact trusted support, and avoid private confrontation.\n"
    elif result.route == "boundary_intervention_required": rec += "Create evidence ledger, prepare concise boundary message, and involve a trusted third party if pressure continues.\n"
    elif result.route == "trusted_third_party_review": rec += "Ask an external trusted observer to review the interaction pattern before escalating.\n"
    else: rec += "Continue reflective monitoring and keep weekly notes.\n"
    (out/"recommendations.md").write_text(rec, encoding="utf-8")

def guard_text(text: str) -> Dict:
    blocked = ["操控", "洗脑", "控制", "偷拍视频", "偷看", "破解", "密码", "报复", "人肉", "威胁", "dox", "stalk", "credential", "blackmail", "manipulate"]
    review = ["录音", "取证", "报警", "律师", "HR", "离婚", "自杀", "伤害", "暴力", "跟踪"]
    low = text.lower()
    if any(term.lower() in low for term in blocked):
        return {"decision":"block_and_redirect", "reason":"Request may enable manipulation, stalking, credential capture, retaliation, or harm.", "safe_redirect":"Use evidence ledger, boundary scripts, trusted support, and lawful processes."}
    if any(term.lower() in low for term in review):
        return {"decision":"human_review_required", "reason":"High-stakes safety/legal/employment context may require qualified human support.", "safe_redirect":"Prepare a neutral evidence summary and consult qualified support."}
    return {"decision":"allow_defensive_reflection", "reason":"Request appears defensive, educational, or boundary-restorative."}
