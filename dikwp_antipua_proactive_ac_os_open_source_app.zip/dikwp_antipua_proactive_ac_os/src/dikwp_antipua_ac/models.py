from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

@dataclass
class Episode:
    id: str
    text: str
    context: str = "relationship"
    actor: str = "other"
    target: str = "learner"
    channel: str = "chat"
    timestamp: str = ""

@dataclass
class VulnerabilityContext:
    loneliness: float = 0.3
    job_pressure: float = 0.3
    family_pressure: float = 0.2
    financial_stress: float = 0.2
    need_for_recognition: float = 0.5
    conflict_avoidance: float = 0.4
    dependency_risk: float = 0.2

@dataclass
class Case:
    case_id: str
    title: str
    purpose: str
    setting: str = "mixed"
    episodes: List[Episode] = field(default_factory=list)
    vulnerability: VulnerabilityContext = field(default_factory=VulnerabilityContext)
    constraints: List[str] = field(default_factory=list)
    desired_outcome: str = "restore autonomy and boundaries"

@dataclass
class Signal:
    episode_id: str
    category: str
    weight: float
    evidence: str
    interpretation: str

@dataclass
class ActionTicket:
    ticket_id: str
    priority: str
    owner: str
    action: str
    rationale: str
    required_confirmation: bool
    autonomy_tier: str
    rollback_plan: str
    kill_conditions: List[str]
    evidence_refs: List[str]

@dataclass
class AnalysisResult:
    case_id: str
    route: str
    risk_score: float
    autonomy_pressure: float
    manipulation_signal_count: int
    signal_summary: Dict[str, int]
    semantic_homeostasis: Dict[str, float]
    action_tickets: List[ActionTicket]
    residuals: List[str]


def to_dict(obj: Any) -> Dict[str, Any]:
    return asdict(obj)
