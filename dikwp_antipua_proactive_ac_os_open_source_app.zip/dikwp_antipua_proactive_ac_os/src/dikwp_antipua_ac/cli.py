import argparse, json
from .analyzer import load_case, write_outputs, guard_text
from .static_audit import write_audit

def main():
    p=argparse.ArgumentParser(prog="antipua-ac")
    sub=p.add_subparsers(dest="cmd", required=True)
    a=sub.add_parser("analyze"); a.add_argument("case"); a.add_argument("--out", default="outputs/demo")
    g=sub.add_parser("guard"); g.add_argument("text")
    s=sub.add_parser("static-audit"); s.add_argument("root"); s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    ns=p.parse_args()
    if ns.cmd=="analyze":
        case=load_case(ns.case); write_outputs(case, ns.out); print(json.dumps({"ok":True,"out":ns.out}, ensure_ascii=False))
    elif ns.cmd=="guard":
        print(json.dumps(guard_text(ns.text), ensure_ascii=False, indent=2))
    elif ns.cmd=="static-audit":
        print(json.dumps(write_audit(ns.root, ns.out), ensure_ascii=False, indent=2))
if __name__ == "__main__": main()
