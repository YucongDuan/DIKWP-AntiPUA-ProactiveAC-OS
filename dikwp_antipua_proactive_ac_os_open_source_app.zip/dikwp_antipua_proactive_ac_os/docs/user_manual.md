# User Manual

1. Open `index.html` or run CLI.
2. Paste interaction episodes into a JSON case.
3. Run `antipua-ac analyze`.
4. Review signal matrix.
5. Read DIKWP ledger.
6. Use boundary scripts only if safe.
7. Contact trusted support if route is urgent or high risk.
8. Do not retaliate.
