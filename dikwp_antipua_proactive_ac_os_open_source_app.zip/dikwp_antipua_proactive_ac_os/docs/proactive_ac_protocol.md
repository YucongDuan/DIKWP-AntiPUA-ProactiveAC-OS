# Proactive AC Protocol

Proactive AC means active semantic stewardship, not subjective consciousness.

The system proactively monitors:

- Truth integrity
- Boundary integrity
- Intent coherence
- Consent integrity
- Residual capacity
- Recovery readiness

When risk rises, the system produces Action Tickets instead of executing external actions.
