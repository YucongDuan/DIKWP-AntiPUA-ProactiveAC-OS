# Nietzsche Genealogy Framework

The Nietzsche layer asks:

1. Which value word is being invoked?
2. Who benefits if the target accepts that value unexamined?
3. What cost is hidden behind moral language?
4. Is will to power becoming capability formation or domination?
5. Is ressentiment driving retaliation?
6. Can the action survive the eternal recurrence test?

Safe interpretation: restore agency and self-overcoming.
Unsafe interpretation: domination, humiliation, revenge, cult obedience, or biological superiority.
