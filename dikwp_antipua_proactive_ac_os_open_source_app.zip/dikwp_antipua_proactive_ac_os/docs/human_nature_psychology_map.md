# Human Nature Psychology Map

The system focuses on defensive recognition of pressure points:

- Need for recognition
- Fear of abandonment
- Shame avoidance
- Conflict avoidance
- Status anxiety
- Dependency risk
- Rescue fantasy
- Fatigue and learned helplessness
- Trust hunger
- Debt and gratitude confusion

These are not manipulation handles. They are self-protection signals used to restore consent, boundaries and reflective agency.
