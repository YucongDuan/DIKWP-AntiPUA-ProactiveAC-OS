# Counter-PUA Action Playbook

Allowed actions:

1. Slow down decisions.
2. Record exact observable behavior.
3. Ask for written scope and specifics.
4. Refuse shame-based obligations.
5. Keep external support channels open.
6. Preserve lawful evidence.
7. Escalate to qualified support when safety, employment, legal or health stakes are high.

Blocked actions:

- revenge manipulation
- doxxing
- stalking
- credential capture
- hidden recording where unlawful
- threats
- illegal exposure
- retaliatory harassment
