# Governance Boundary

This system is for defensive education and boundary restoration. It must not be used for covert surveillance, manipulation, stalking, credential capture, retaliation, clinical diagnosis, legal conclusion, or high-impact automation.

The system evaluates interaction signals, not souls or hidden minds.
