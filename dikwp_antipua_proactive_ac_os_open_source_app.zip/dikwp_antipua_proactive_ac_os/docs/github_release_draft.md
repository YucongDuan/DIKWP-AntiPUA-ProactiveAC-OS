# GitHub Release Draft

DIKWP AntiPUA ProactiveAC OS v0.1.0

A defensive, offline system for recognizing manipulation, PUA, gaslighting, shame hooks, isolation pressure and coercive patterns using DIKWP-Mesh 4.0, Nietzsche genealogy, Jung shadow literacy and semantic homeostasis.
