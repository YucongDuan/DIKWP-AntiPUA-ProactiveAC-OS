# Architecture

Pipeline:

```text
Interaction Episode Intake
→ Pattern Signal Scanner
→ Human-Nature Pressure Map
→ Nietzsche Genealogy Cards
→ Jung Shadow/Projection Map
→ DIKWP Manipulation Ledger
→ Semantic Homeostasis Trace
→ Action Tickets
→ Boundary Scripts
→ Safety / Recovery Plan
```

The offline core does not use network, browser automation, hidden telemetry, credential capture, or external action execution.
