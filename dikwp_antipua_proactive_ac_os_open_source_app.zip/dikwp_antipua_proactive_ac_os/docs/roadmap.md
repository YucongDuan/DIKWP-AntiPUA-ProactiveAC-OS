# Roadmap

- v0.2: multilingual signal library
- v0.3: workplace-specific pack
- v0.4: family and school boundary pack
- v0.5: support organization handoff templates
- v1.0: DIKWP AntiPUA Steward certification kit
