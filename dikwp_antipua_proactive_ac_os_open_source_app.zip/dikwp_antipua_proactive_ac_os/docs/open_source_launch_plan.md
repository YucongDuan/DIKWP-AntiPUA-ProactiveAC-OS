# Open Source Launch Plan

Suggested repository name: DIKWP-AntiPUA-ProactiveAC-OS

Launch assets:

- README
- standalone HTML demo
- sample case
- CLI
- tests
- boundary policy
- Nietzsche/Jung framework docs
- TrustPassport seed
