# Jung Shadow and Boundary Framework

The Jung layer treats manipulative interactions as possible activations of projection, persona idealization, complexes and shadow displacement.

It does not diagnose either party. It asks:

- What self-image is being inflated?
- What shame complex is activated?
- What projection is being placed on the target?
- Which external mirrors have been removed?
- What individuation step restores the target's agency?

Repair means externalizing memory, reconnecting with plural observers, and separating identity from the request.
