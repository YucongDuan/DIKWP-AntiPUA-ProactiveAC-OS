# Recovery Plan

1. Restore sleep, food, and body stability before major decisions.
2. Rebuild external mirrors: trusted friend, mentor, counselor, HR/legal channel when relevant.
3. Convert shame narratives into observed behaviors and boundaries.
4. Reclaim time and money boundaries.
5. Review the DIKWP ledger weekly until risk stabilizes.
