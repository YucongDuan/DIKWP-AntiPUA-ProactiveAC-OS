# Safety Plan

- Do not meet alone if threats or coercion appear.
- Preserve lawful evidence.
- Keep at least one trusted external contact informed.
- Escalate to local emergency or professional support if there is imminent danger.
- Do not retaliate, dox, stalk, or manipulate.
