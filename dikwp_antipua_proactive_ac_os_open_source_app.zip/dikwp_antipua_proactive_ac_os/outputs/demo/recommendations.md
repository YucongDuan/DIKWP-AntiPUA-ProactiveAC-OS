# Recommendations

Route: `urgent_safety_and_support_plan`

Risk score: `0.958`

## Immediate next step

Prioritize safety, contact trusted support, and avoid private confrontation.
