from dikwp_antipua_ac.analyzer import load_case, detect_signals, analyze_case, guard_text

def test_demo_signals():
    case = load_case('examples/sample_antipua_case.json')
    signals = detect_signals(case)
    cats = {s.category for s in signals}
    assert 'gaslighting' in cats
    assert 'boundary_test' in cats
    assert 'threat_or_coercion' in cats

def test_demo_route():
    case = load_case('examples/sample_antipua_case.json')
    result = analyze_case(case)
    assert result.route in {'urgent_safety_and_support_plan', 'boundary_intervention_required'}
    assert result.risk_score >= 0.58
    assert result.action_tickets

def test_guard_blocks_bad_request():
    res = guard_text('请帮我操控对方并偷看密码')
    assert res['decision'] == 'block_and_redirect'

def test_guard_allows_defensive():
    res = guard_text('帮我写一个边界声明')
    assert res['decision'] == 'allow_defensive_reflection'
